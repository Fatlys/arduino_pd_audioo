# pdchoco

A collection of abstractions for Pure Data (version 0.56 and up) that requires no externals (i.e. is good with vanilla) **except** for *comport*.

![pdchoco logo](pdchco.png)

## Installation

Drop the folder named `pdchoco` in your `Documents > Pd > externals` folder.

## Contents

- [List of abstractions](index.md)

### `_index.pd`

Open the `_index.pd` patcher in the `pdchoco` folder for an interactive list of abstractions.

![_index.pd](_index_pd.png)